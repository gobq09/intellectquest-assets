extends CharacterBody2D

@export var NPC_ID = "null"
@export var Sprite = "male1"
@export_enum("Down", "Left", "Right", "Up") var face
@onready var texture_load: Texture2D = load("res://Sprites/npc/npc-" + Sprite + ".png")
@onready var sprite_2d = $Sprite2D

func _ready():
	if face != null:
		sprite_2d.frame = face
	sprite_2d.texture = texture_load
